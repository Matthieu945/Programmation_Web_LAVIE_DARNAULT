let slideIndex = 0;
let attempts = 0;

// carousel
function currentSlide(n) {
    slideIndex = n;
    showSlides(slideIndex);
}

function showSlides(n) {
    const slides = document.querySelectorAll('.carousel-item');
    const dots = document.querySelectorAll('.dot');
    if (slides.length === 0) return;
    if (n >= slides.length) slideIndex = 0;
    if (n < 0) slideIndex = slides.length - 1;
    slides.forEach(s => s.classList.remove('active'));
    dots.forEach(d => d.classList.remove('active'));
    slides[slideIndex].classList.add('active');
    if (dots.length > 0) dots[slideIndex].classList.add('active');
}

// quiz
function quizAlert() {
    alert("Vous êtes sur le point de commencer le quiz !");
    quizConfirm();
}

function quizConfirm() {
    let res = confirm("Êtes-vous sûr de vouloir commencer ?");
    if (res) {
        const startBtn = document.getElementById('startBtn');
        const infoSection = document.getElementById('informations');
        if (startBtn) startBtn.style.display = 'none';

        let timer = 5;
        let countdownDisplay = document.createElement("div");
        countdownDisplay.style.cssText = "font-size: 3rem; font-weight: 800; color: #003d80; text-align: center; margin: 20px;";
        countdownDisplay.textContent = timer;
        infoSection.appendChild(countdownDisplay);

        let interval = setInterval(() => {
            timer--;
            countdownDisplay.textContent = timer;
            if (timer <= 0) {
                clearInterval(interval);
                countdownDisplay.remove();
                const quizContent = document.querySelector('fieldset.quiz');
                const submitBtn = document.getElementById('submitQuiz');
                if (quizContent) quizContent.style.display = 'block';
                if (submitBtn) submitBtn.style.display = 'block';
            }
        }, 1000);
    } else {
        alert("Dommage ! Redirection vers l'accueil...");
        window.location.href = "index.html";
    }
}

//json
class MessageHistory {
    constructor() {
        const saved = localStorage.getItem('contactMessages');
        this.messages = saved ? JSON.parse(saved) : [];
    }
    addMessage(msg) {
        this.messages.push(msg);
        localStorage.setItem('contactMessages', JSON.stringify(this.messages));
    }
    getHistory() { return this.messages; }
}
const historyManager = new MessageHistory();


document.addEventListener('DOMContentLoaded', () => {
    showSlides(slideIndex);
    
    // Auto-carrousel
    setInterval(() => { slideIndex++; showSlides(slideIndex); }, 6000);

    document.getElementById('next')?.addEventListener('click', () => { slideIndex++; showSlides(slideIndex); });
    document.getElementById('prev')?.addEventListener('click', () => { slideIndex--; showSlides(slideIndex); });

    const quizForm = document.getElementById('quizForm');
    const submitBtn = document.getElementById('submitQuiz');

    if (quizForm) {
        quizForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            attempts++; 
            
            let score = 0;
            const q1 = document.querySelector('input[name="q1"]:checked');
            if (q1?.value === 'a') score += 4;

            if (document.getElementById('q2a')?.checked) score += 3;
            if (document.getElementById('q2b')?.checked) score += 3;
            if (document.getElementById('q2c')?.checked) score -= 3;

            const q3 = document.getElementById('q3text')?.value.toLowerCase() || "";
            if (['réduire', 'alléger', 'faciliter', 'optimiser', 'exploiter'].some(m => q3.includes(m))) score += 10;

            const scoreDisp = document.getElementById('scoreDisplay');
            const attBody = document.getElementById('attemptsBody');
            const retryBtn = document.getElementById('retryBtn');
            const questions = document.querySelector('fieldset.quiz');

            if (scoreDisp) {
                document.getElementById('quizResult').style.display = 'block';
                scoreDisp.innerText = `Score final : ${score} / 20`;
                if (attBody) attBody.insertRow().innerHTML = `<td>${attempts}</td><td>${score} / 20</td>`;

                if (score === 20 || attempts >= 3) {
                    if (submitBtn) submitBtn.style.display = 'none';
                    if (retryBtn) retryBtn.style.display = 'block';
                    if (questions) questions.style.display = 'none';
                    if (score === 20) launchConfetti();
                    alert(score === 20 ? "Score parfait !" : "Maximum de tentatives atteint.");
                } else {
                    alert(`Tentative n°${attempts} finie. Reste ${3 - attempts}.`);
                    quizForm.reset();
                }
            }
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        });
    }
//formulaire
    const contactForm = document.getElementById('mainContactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                nom: document.getElementById('name').value,
                email: document.getElementById('email').value,
                statut: document.getElementById('user-status')?.value || 'N/A',
                sujet: document.getElementById('subject')?.value || 'N/A',
                message: document.getElementById('message').value,
                date: new Date().toLocaleString()
            };
            historyManager.addMessage(data);
            alert("Message sauvegardé localement !");
            contactForm.reset();
        });
    }
});

function launchConfetti() {
    for (let i = 0; i < 100; i++) {
        let confetti = document.createElement("div");
        confetti.className = "confetti";
        confetti.style.left = Math.random() * 100 + "vw";
        confetti.style.backgroundColor = ["#f2d74e", "#95c3de", "#ff9a91", "#2ecc71"][Math.floor(Math.random() * 4)];
        confetti.style.animationDelay = Math.random() * 2 + "s";
        confetti.style.width = Math.random() * 10 + 5 + "px";
        confetti.style.height = confetti.style.width;
        document.body.appendChild(confetti);
        setTimeout(() => confetti.remove(), 4000);
    }
}